class UserDataFetch {
  static fetchUserData() {
    return new Promise((resolve, reject) => {
      fetch("https://jsonplaceholder.typicode.com/users")
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response not working...!");
          }
          return response.json();
        })
        .then((data) => resolve(data))
        .catch((error) => reject(error));
    });
  }
}
function renderData(users) {
  try {
    const tableBody = document.getElementById("emplist");
    tableBody.innerHTML = "";
    users.forEach((user) => {
      const row = `
            <tr>
                <td>${user.id}</td>
                    <td>${user.name}</td>
                        <td>${user.email}</td>
            </tr>`;
      tableBody.innerHTML += row;
    });
  } catch (error) {
    console.log(error.message);
  }
}

UserDataFetch.fetchUserData().then((users) => renderData(users));
