
function multiply(a: number, b: number): number {
    return a * b
}

const a = 13
const b = 13

console.log(` output ${a} * ${b} = ${multiply(a, b)}`);
