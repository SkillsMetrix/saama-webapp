function showMessage() {
    console.log('welcome to console');

    document.getElementById('show').innerHTML = 'Text using JS'
}
