class UserDataFetch {
  static async fetchUserData() {
    try {
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/users"
      );
      if (!response.ok) {
        throw new Error("Network response not working...!");
      }
      return await response.json();
    } catch (error) {
      console.log(error);
      return [];
    }
  }
}
function renderData(users) {
  try {
    const tableBody = document.getElementById("emplist");
    tableBody.innerHTML = "";
    users.forEach((user) => {
      const row = `
            <tr>
                <td>${user.id}</td>
                    <td>${user.name}</td>
                        <td>${user.email}</td>
            </tr>`;
      tableBody.innerHTML += row;
    });
  } catch (error) {
    console.log(error.message);
  }
}
async function initApp() {
  const users = await UserDataFetch.fetchUserData();
  renderData(users);
}
initApp();
