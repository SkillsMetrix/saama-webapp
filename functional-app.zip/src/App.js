import logo from './logo.svg';
import './App.css';
import UserApp from './components/UserApp';
import ContextApp from './components/ContextApp';
import { MyContext } from './contextapi/MyContext';
import { useState } from 'react';
import MainComp from './contextapi/MainComp';
import UserAppNew from './components/UserAppNew';

const userData=[{uname:'Amarjeet',city:'pune'}]
function App() {
  const [user,setUser]=useState(userData)
  return (
     <div className="App">
     <UserAppNew/>
    </div>  
   /*  <MyContext.Provider value={user}>
      <MainComp/>
    </MyContext.Provider> */
  );
}

export default App;
