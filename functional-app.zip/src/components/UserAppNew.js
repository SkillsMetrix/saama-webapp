import React, { useState } from "react";

function UserAppNew(props) {
  const [users, setUsers] = useState([]);

  const handleChange = (e) => {
    //setUsers({ ...users, [e.target.name]: e.target.value });
    setUsers({ ...users, [e.target.name]: e.target.value });
  };
  const addUser = (e) => {
    e.preventDefault();
    console.log(users);
  };
  return (
    <div>
      <form onSubmit={addUser}>
        UserName: <input type="text" name="uname" onChange={handleChange} />
        Email: <input type="text" name="email" onChange={handleChange} />
        <button>Add User</button>
      </form>
    </div>
  );
}

export default UserAppNew;
