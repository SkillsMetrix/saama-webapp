import React from 'react';
import MyComponent from './MyComponent';

function MainComp(props) {
    return (
        <div>
           <MyComponent/>
        </div>
    );
}

export default MainComp;