import React, { useContext } from 'react';
import { MyContext } from './MyContext';

function MyComponent(props) {

    const mydata= useContext(MyContext)
    return (
        <div>
            UserData:
            {mydata.map((data)=> (
                <div key={data}>{data.uname}</div>
            ))}

            
        </div>
    );
}

export default MyComponent;