const express = require("express");
const bp = require("body-parser");
const jwt = require("jsonwebtoken");
const config = require("./config.json");
const router = express.Router();
const app = express();
app.use(bp.json());
router.post("/login", (req, res) => {
  const postdata = req.body;
  const user = {
    uname: postdata.uname,
    password: postdata.password,
  };
  const token = jwt.sign(user, config.secret, { expiresIn: config.tokenlife });
  const response = {
    status: "logged in",
    token: token,
  };
  res.send(response);
});
router.use(require("./tokenChecker"));
router.get("/userdetails", (req, res) => {
  res.send("user details");
});
app.use("/api", router);

app.listen(3000, () => {
  console.log("server is ready");
});
