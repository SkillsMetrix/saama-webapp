import ProductDetail from "./containers/ProductDetail";
import ProductListing from "./containers/ProductListing";


export const routes=[
    {path:'/' ,element:<ProductListing/>},
    {path:'/product/:pid' ,element:<ProductDetail/>}
]