import { ActionTYpes } from "../constants/action-types";

const initialState = {
  products: [],
};

export const productReducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case ActionTYpes.SET_PRODUCTS:
      return { ...state, products: payload };
    case ActionTYpes.FETCH_PRODUCTS:
      return { ...state, products: payload };
    default:
      return state;
  }
};

export const selectedProductReducer = (state = {}, { type, payload }) => {
  switch (type) {
    case ActionTYpes.SELECTED_PRODUCT:
      return { ...state, ...payload };
    default:
      return state;
  }
};
