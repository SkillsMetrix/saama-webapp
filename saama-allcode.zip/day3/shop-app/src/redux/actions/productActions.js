import fakeStoreApi from "../../apis/fakeStoreApi";
import { ActionTYpes } from "../constants/action-types";

export const fetchProducts = () => async (dispatch) => {
  const response = await fakeStoreApi.get("/products");
  dispatch({ type: ActionTYpes.FETCH_PRODUCTS, payload: response.data });
};


export const fetchProduct = (id) => async (dispatch) => {
  const response = await fakeStoreApi.get(`/products/${id}`);
  dispatch({ type: ActionTYpes.SELECTED_PRODUCT, payload: response.data });
};

