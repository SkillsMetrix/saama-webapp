export const GET_USER_FETCH = "GET_USER_FETCH";
export const GET_USER_SUCCESS = "GET_USER_SUCCESS";

export const getUserFetch = () => {
  return {
    type: GET_USER_FETCH,
  };
};
