import logo from './logo.svg';
import './App.css';
import {useDispatch} from 'react-redux'
import { useEffect } from 'react';
import { getUserFetch } from './redux/actions';

function App() {
  const dispatch= useDispatch()

  useEffect(()=>{
dispatch(getUserFetch())
  },[])
  return (
    <div className="App">
      <header className="App-header">
      
      </header>
    </div>
  );
}

export default App;
