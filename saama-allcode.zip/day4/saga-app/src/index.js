import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import createSagaMiddleware from "redux-saga";
import mySaga from "./redux/saga";
import { combineReducers, createStore, applyMiddleware } from "redux";
import appReducer from "./redux/reducer";
import { Provider } from "react-redux";
const root = ReactDOM.createRoot(document.getElementById("root"));
const sm = createSagaMiddleware();
const rootReducer = combineReducers({ appReducer });
const store = createStore(rootReducer, applyMiddleware(sm));
sm.run(mySaga);
root.render(
  <Provider store={store}>
    <App />
  </Provider>
);
