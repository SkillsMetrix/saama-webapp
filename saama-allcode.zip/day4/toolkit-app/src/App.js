import logo from "./logo.svg";
import "./App.css";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { loadUsers } from "./redux/userState";

function App() {
  const udata= useSelector((state)=> state.useData.users)
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(loadUsers());
  }, []);
  return <div className="App">
    {udata.map((data)=>(
      <div>{data.name} --- {data.email}</div>
    ))}
  </div>;
}

export default App;
