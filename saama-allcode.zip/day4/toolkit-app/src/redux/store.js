import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./userState";

const rootStore = configureStore({
  reducer: {
    useData: userReducer,
  },
});

export default rootStore;
