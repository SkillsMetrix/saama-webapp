

module.exports={
    logger:function(req,res,next){
        console.log(`Request ${new Date().toString()} invoked ${req.method} and url is ${req.originalUrl}`);
        next()
    } ,
    requireAuth:function(req,res,next){
        console.log('private URL is hit');
        
        next()
    }
}