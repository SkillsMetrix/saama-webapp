

var express= require('express')
var bp= require('body-parser')
var _ =require('underscore')
const middleware = require('./middleware')
var app= express()

app.use(express.static('public'))
app.use(bp.json())
uid=1

 

app.use(middleware.logger)
var userData=[
]

app.get('/loadusers',(req,res)=>{
    res.send(userData)
})
app.get("/loaduser/:id",(req,res)=>{
    var uid= parseInt(req.params.id)
    var foundData= _.findWhere(userData,{id:uid})
    if(foundData){
        res.send(foundData)
    }else{
        res.send('user not found')
    }
    
})

app.delete("/deleteuser/:id",(req,res)=>{
    var uid= parseInt(req.params.id)
    var foundData= _.findWhere(userData,{id:uid})
    if(foundData){
        userData=_.without(userData,foundData)
        res.send('user deleted')
    }else{
        res.send('user not found')
    }
    
})

app.put('/updateuser/:id',(req,res)=>{
    var uid= parseInt(req.params.id)
    var foundData= _.findWhere(userData,{id:uid})
    if(foundData){
        var body=_.pick(req.body,'uname','email')
        var data={}
        data.uname=body.uname
        data.email=body.email
        _.extend(foundData,data)
        res.send('user updated')
    }
})

app.post('/adduser',middleware.requireAuth,(req,res)=>{
    var udata= req.body
    udata.id=uid++
    userData.push(udata)
    res.send('user added')
    
})

app.listen(3000,()=>{
    console.log('server is ready..!');
    
})