let employees = [];
let editIndex = -1;

function showEmp() {
  const list = document.getElementById("emplist");
  list.innerHTML = "";
  employees.forEach((emp, index) => {
    list.innerHTML += `
        <li>
        <span>${emp.empId} - ${emp.empName} - ${emp.empcity}</span>
        <div>
        <button class="edit-btn"onclick="editEmployee(${index})" >Edit</button>
        <button class="delete-btn" onclick="deleteEmp(${index})">Delete</button>
        </div>
        </li>`;
  });
}

function addorUpdateEmployee() {
  const empId = document.getElementById("empid").value;
  const empName = document.getElementById("empname").value;
  const empcity = document.getElementById("empcity").value;

  if (empId && empName && empcity) {
    if (editIndex === -1) {
      employees.push({ empId, empName, empcity });
    } else {
      employees[editIndex] = { empId, empName, empcity };
      editIndex = -1;
      document.getElementById("btn").textContent = "Add Employee";
    }
    document.getElementById("empid").value = "";
    document.getElementById("empname").value = "";
    document.getElementById("empcity").value = "";

    showEmp();
  }
}

function editEmployee(index) {
  const emp = employees[index];
  document.getElementById("empid").value = emp.empId;
  document.getElementById("empname").value = emp.empName;
  document.getElementById("empcity").value = emp.empcity;
  document.getElementById("btn").textContent = "Update Employee";
  editIndex = index;
  console.log(editIndex);
}
function deleteEmp(index) {
  employees.splice(index, 1);
  showEmp();
}
