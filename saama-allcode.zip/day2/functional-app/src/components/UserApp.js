import { useEffect, useState } from "react";
function UserApp() {
  const [users, setUsers] = useState([]);
  const [uname, setUname] = useState("");
  const [email, setEmail] = useState("");

  //when app loads
  useEffect(() => {
    console.log("called onload");
  }, []);
  //when app changes
  useEffect(() => {
    console.log("called on update");
  }, [users]);

  const addUser = (e) => {
    e.preventDefault();
     

    setUsers([...users, { uname, email }]);
  };
  const deleteUser = (user) => {
    setUsers(users.filter((use) => use.uname !== user));
  };
  return (
    <div>
      <div>
        {users.map((data) => (
          <div>
            <div>{data.uname}</div>
            <div>{data.email}</div>
            <button onClick={() => deleteUser(data.uname)}>Delete</button>
          </div>
        ))}
      </div>
      <form onSubmit={addUser}>
        UserName:{" "}
        <input
          type="text"
          value={uname}
          onChange={(e) => setUname(e.target.value)}
        />
        Email:{" "}
        <input
          type="text"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button>Add User</button>
      </form>
    </div>
  );
}
export default UserApp;
