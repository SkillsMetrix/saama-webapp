function Header(props) {
  return <p>{props.title}</p>;
}

export default Header;
