function AddUser(props) {
  const addUser = (e) => {
    e.preventDefault();
    const data = e.target.elements.uname.value;
    props.adduser(data);
  };

  return (
    <div>
      <form onSubmit={addUser}>
        UserName: <input type="text" name="uname" />
        <button>Add USer</button>
      </form>
    </div>
  );
}
export default AddUser;
