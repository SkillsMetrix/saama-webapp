import axios from "axios";
import { Component } from "react";
const URL = "https://jsonplaceholder.typicode.com/users";
export default class RestApp extends Component {
  state = {
    userdata: [],
  };
  componentDidMount() {
    axios
      .get(URL)
      .then((res) => res.data)
      .then((data) => {
        console.log(data);
      });
  }
  render(){
    return(
        <div></div>
    )
  }
}
