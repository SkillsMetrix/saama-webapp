 import User from "./User";

function Users(props) {
  

    return (
      <div>
    {props.udata.map((data)=><User key={data} ud={data} du={props.duser}/>)}
    <User/>
    </div>
    )
  }


  export default Users