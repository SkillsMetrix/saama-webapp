import React, { Component } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Users from "./Users";
import AddUser from "./AdUser";

export default class MainApp extends Component {
  componentDidMount() {
    const json = localStorage.getItem("saama");
    const userData = JSON.parse(json);
    if (userData) {
      this.setState(() => {
        return {
          userData,
        };
      });
    }
  }
  componentDidUpdate() {
    const json = JSON.stringify(this.state.userData);
    localStorage.setItem("saama", json);
  }
  // initialize the state
  state = {
    headerTitle: "Welcome to Header Component",
    userData: [],
  };

  deleteUser = (data) => {
    this.setState((prevState) => {
      return {
        userData: prevState.userData.filter((udata) => data !== udata),
      };
    });
  };
  addUser = (data) => {
    this.setState((prevState) => {
      return {
        userdata: prevState.userData.push(data),
      };
    });
  };
  deleteAll = () => {
    this.setState(() => {
      return {
        userData: [],
      };
    });
  };
  render() {
    return (
      <div>
        <Header title={this.state.headerTitle} />
        <p>Welcome to MainApp</p>
        <Users duser={this.deleteUser} udata={this.state.userData} />
        <AddUser adduser={this.addUser} />
        <Footer hasData={this.state.userData.length > 0} da={this.deleteAll} />
      </div>
    );
  }
}
