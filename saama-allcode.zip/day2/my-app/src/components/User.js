function User(props) {
  return (
    <div>
      {props.ud}
      <button onClick={() => props.du(props.ud)}>Delete</button>
    </div>
  );
}

export default User;
