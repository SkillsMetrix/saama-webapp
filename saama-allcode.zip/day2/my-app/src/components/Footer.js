function Footer(props) {
  return (
    <div>
      <button disabled={!props.hasData} onClick={props.da}>
        Delete All
      </button>
    </div>
  );
}
export default Footer;
