var express= require('express')
const connectDB = require("./config/db");
const cors= require('cors')
const authRoutes= require('./routes/auth')
const app=express()

app.use(cors())
app.use(express.json())

connectDB();
app.use('/api/auth',authRoutes)

app.listen(3200,()=>{
    console.log('server is ready...!');
    
})



