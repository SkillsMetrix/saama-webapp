const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

const JWT_SECRET = "dummy_value";
const router = express.Router();
router.post("/register", async (req, res) => {
  const { username, password } = req.body;
  console.log(username);
  console.log(password);
  const hashed = await bcrypt.hash(password, 10);
  console.log(hashed);

  try {
    console.log("getting stored");
    const newUser = await User.create({ username, password: hashed });
    console.log(newUser);

    res.status(201).json({ message: "User Registered", data: newUser });
  } catch (err) {
    res.status(400).json({ error: "User Already exists" });
  }
});

router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.status(401).json({ message: "Invalid Credentials" });

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.status(401).json({ message: "Invalid Credentials" });
  const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: "1h" });
  res.json({ token, username: user.username });
});
module.exports = router;
