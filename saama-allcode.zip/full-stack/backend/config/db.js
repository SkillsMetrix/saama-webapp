

const mongoose= require('mongoose')
const connectDB= async() =>{
    try{
        console.log('getting connected');
        
        await mongoose.connect("mongodb+srv://saama:saama@cluster0.rle5i.mongodb.net/saamadb?retryWrites=true&w=majority&appName=Cluster0")
        //await mongoose.connect("mongodb://localhost:27017/saamadb")

        console.log('connected to DB');
        
    }catch(err){}
}
module.exports=connectDB;