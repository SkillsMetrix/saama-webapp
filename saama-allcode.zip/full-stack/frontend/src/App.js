import logo from './logo.svg';
import './App.css';
import Register from './components/Register';
import Navbar from './components/Navbar';
import DashBoard from './components/DashBoard';

function App() {
  return (
    <div className="App">
      <Navbar/>
      <hr/>
      <DashBoard/>
     </div>
  );
}

export default App;
