import DashBoard from "./components/DashBoard";
import Login from "./components/Login";
  import Register from "./components/Register";
import UserDetails from "./components/UserDetails";



export const routes=[
    {path:'/',element:<Login/>},
    {path:'/login',element:<Login/>},

     {path:'/register',element:<Register/>},
     {path:'/userdetails',element:<UserDetails/>}

]