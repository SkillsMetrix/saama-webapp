import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API = "http://localhost:3200/api/auth";

export const register = createAsyncThunk("auth/register", async (userData) => {
  await axios.post(`${API}/register`, userData);
});
export const login = createAsyncThunk("auth/login", async (userData) => {
  const res = await axios.post(`${API}/login`, userData);
  return res.data;
});

const authSlice = createSlice({
  name: "auth",
  initialState: {
    user: null,
    token: null,
    status: null,
  },
  reducers: {
    logout: (state) => {
      state.user = null;
      state.token = null;
      localStorage.removeItem('token')
      localStorage.removeItem('username')
    },
  },
  extraReducers: (builder) => {
    builder.addCase(login.fulfilled, (state, action) => {
      state.user = action.payload.username;
      state.token = action.payload.token;
      localStorage.setItem('token',action.payload.token)
      localStorage.setItem('username',action.payload.username)

    });
  },
});
export const { logout } = authSlice.actions;
export default authSlice.reducer;
