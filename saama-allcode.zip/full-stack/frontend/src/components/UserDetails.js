import React from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom';
import { logout } from '../redux/authSlice';
function UserDetails() {
    const navigate=useNavigate()
    const token= useSelector(state => state.auth.token)
    const dispatch=useDispatch()
    console.log(token);
    
    if (token==null) 
       navigate("/login")
    
    const handleLogout=()=>{
        dispatch(logout())
        navigate("/login")
    }

    return (
        <div>
            UserDetails after logged in
            <button onClick={handleLogout}>Logout</button>
           
        </div>
    );
}


export default UserDetails;