
import React, { useState } from 'react';
import { useDispatch } from 'react-redux'
import { register } from '../redux/authSlice';
import { useNavigate } from 'react-router-dom'
function Register(props) {

const [formData,setFormData]= useState({username:'',password:''})
const dispatch= useDispatch()
const navigate= useNavigate()
const handleChange=(e)=>{
e.preventDefault();
setFormData({...formData,[e.target.name]:e.target.value})

}
const handleSubmit=async (e) =>{
    e.preventDefault()
  
    
    await dispatch(register(formData)).unwrap()
    navigate('/login')
}
    return (
        <div>
            <form onSubmit={handleSubmit} >
                <h2>User Registration Form</h2>
                UserName: <input type='text' name='username' value={formData.username} onChange={handleChange} placeholder='Enter UserName'/>
                Password: <input type='password' name='password' value={formData.password} onChange={handleChange}  placeholder='Enter Password'/>
            <button>Register</button>
            </form>
        </div>
    );
}

export default Register;