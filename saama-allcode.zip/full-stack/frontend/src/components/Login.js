
import React, { useState } from 'react';
import { useDispatch } from 'react-redux'
import { login } from '../redux/authSlice';
import { useNavigate } from 'react-router-dom'
function Login(props) {

const [formData,setFormData]= useState({username:'',password:''})
const dispatch= useDispatch()
const navigate= useNavigate()

const handleChange=(e)=>{
e.preventDefault();
setFormData({...formData,[e.target.name]:e.target.value})

}
const handleSubmit=async (e) =>{
    e.preventDefault()
    console.log(formData);
    
    await dispatch(login(formData)).unwrap()
    navigate("/userdetails")
}
    return (
        <div>
            <form onSubmit={handleSubmit} >
                <h2>Login Form</h2>
                UserName: <input type='text' name='username' value={formData.username} onChange={handleChange} placeholder='Enter UserName'/>
                Password: <input type='password' name='password' value={formData.password} onChange={handleChange}  placeholder='Enter Password'/>
            <button>Login</button>
            </form>
        </div>
    );
}

export default Login;