import React from 'react';
import {Link} from 'react-router-dom'
function Navbar(props) {
    return (
        <div style={{padding:20}}>
            <nav>
<Link to="/login" style={{marginRight:10}}>Login</Link>
<Link to="/register" style={{marginRight:10}}>Register</Link>

            </nav>
            
        </div>
    );
}

export default Navbar;