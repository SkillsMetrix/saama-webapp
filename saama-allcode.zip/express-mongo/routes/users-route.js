const express= require('express')
const router= express.Router()
const User= require('../models/users')

router.post('/',async(req,res)=>{

    const {uname,password}= req.body

    const newUser= new User({uname,password})
    
    
    const item= await newUser.save()
    console.log(item);
    res.json(item)
})

router.get("/",async(req,res)=>{
    const item= await User.find()
    res.json(item)
})

router.delete("/:id",async(req,res)=>{
    await User.findByIdAndDelete(req.params.id)
    res.json('item deleted')
})

module.exports=router