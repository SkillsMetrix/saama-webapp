

const mongoose= require('mongoose')
const connectDB= async() =>{
    try{

        await mongoose.connect("mongodb+srv://admin:admin123>@cluster0.rle5i.mongodb.net/saamadb?retryWrites=true&w=majority&appName=Cluster0")
        console.log('connected to DB');
        
    }catch(err){}
}
module.exports=connectDB;