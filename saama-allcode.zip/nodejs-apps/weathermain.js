var app = require("./weatherapp.js");
var location = require("./loaction.js");
var argv = require("yargs")
  .option("location", {
    alias: "l",
    demand: false,
    type: "string",
  })
  .help("help").argv;

if (typeof argv.l === "string" && argv.l.length > 0) {
  console.log("LOcation provided by client");
  app(argv.l, function (callback) {
    console.log(callback);
  });
} else {
  console.log("Location did not recieved, detecting .....!");
  location(function (location) {
    if (location) {
      app(location.city, function (cw) {
        console.log(cw);
      });
    }
  });
}
