var request = require("request");

module.exports = function (location, callback) {
  var ec = encodeURIComponent(location);

  var url = `http://api.openweathermap.org/data/2.5/weather?q=${ec},uk&appid=b3aaa0b3323c0baab93aff38f75b44cb&units=metric`;

  if (!location) {
    return callback("No Location Provided");
  }
  request(
    {
      url: url,
      json: true,
    },
    function (error, response, body) {
      if (error) {
        callback("unable to reach server...!");
      } else {
        callback(`its ${body.main.temp} in ${body.name}`);
      }
    }
  );
};
