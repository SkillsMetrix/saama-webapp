import { ActionTYpes } from "../constants/action-types";

export const setProducts = (products) => {
  return {
    type: ActionTYpes.SET_PRODUCTS,
    payload: products,
  };
};

export const selectedProducts = (product) => {
  return {
    type: ActionTYpes.SELECTED_PRODUCT,
    payload: product,
  };
};
