


export const ActionTYpes={

    SET_PRODUCTS:"SET_PRODUCTS",
    SELECTED_PRODUCT:"SELECTED_PRODUCT",
    
}